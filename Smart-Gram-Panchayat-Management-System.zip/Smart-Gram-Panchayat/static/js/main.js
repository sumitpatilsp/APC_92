document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-search]").forEach(input => {
    input.addEventListener("input", () => {
      const query = input.value.toLowerCase();
      const table = input.closest(".panel").querySelector("tbody");
      if (!table) return;
      table.querySelectorAll("tr").forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(query) ? "" : "none";
      });
    });
  });
});
