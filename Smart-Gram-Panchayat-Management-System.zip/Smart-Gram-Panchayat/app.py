from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
from functools import wraps
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB_PATH = Path(__file__).with_name("gram_panchayat.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS citizens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, age INTEGER, gender TEXT, phone TEXT,
            address TEXT NOT NULL, ward TEXT
        );
        CREATE TABLE IF NOT EXISTS complaints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            citizen_name TEXT NOT NULL, subject TEXT NOT NULL,
            description TEXT NOT NULL, status TEXT DEFAULT 'Pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS certificates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            applicant TEXT NOT NULL, certificate_type TEXT NOT NULL,
            phone TEXT, status TEXT DEFAULT 'Pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS taxes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            citizen_name TEXT NOT NULL, property_no TEXT,
            amount REAL NOT NULL, status TEXT DEFAULT 'Unpaid'
        );
        CREATE TABLE IF NOT EXISTS notices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        if db.execute("SELECT COUNT(*) FROM citizens").fetchone()[0] == 0:
            db.executemany(
                "INSERT INTO citizens (name,age,gender,phone,address,ward) VALUES (?,?,?,?,?,?)",
                [
                    ("Aarav Patil", 35, "Male", "9876543210", "Main Road", "Ward 1"),
                    ("Sakshi Jadhav", 28, "Female", "9876501234", "Shivaji Chowk", "Ward 2"),
                    ("Rahul More", 42, "Male", "9123456780", "Market Area", "Ward 1")
                ])
            db.executemany(
                "INSERT INTO complaints (citizen_name,subject,description,status) VALUES (?,?,?,?)",
                [("Aarav Patil","Street light not working","Street light near the main road is not working.","Pending"),
                 ("Rahul More","Water supply","Water supply was interrupted yesterday.","In Progress")])
            db.executemany(
                "INSERT INTO certificates (applicant,certificate_type,phone,status) VALUES (?,?,?,?)",
                [("Sakshi Jadhav","Residence Certificate","9876501234","Pending"),
                 ("Rahul More","Birth Certificate","9123456780","Approved")])
            db.executemany(
                "INSERT INTO taxes (citizen_name,property_no,amount,status) VALUES (?,?,?,?)",
                [("Aarav Patil","GP-101",1200,"Paid"),("Sakshi Jadhav","GP-102",950,"Unpaid")])
            db.execute("INSERT INTO notices (title,message) VALUES (?,?)",
                       ("Village cleanliness drive","All residents are requested to participate in the cleanliness drive on Sunday."))

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.route("/", methods=["GET"])
def index():
    return redirect(url_for("dashboard") if session.get("admin") else url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if username == "admin" and password == "admin123":
            session["admin"] = True
            flash("Welcome to the Gram Panchayat dashboard.", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    with get_db() as db:
        stats = {
            "citizens": db.execute("SELECT COUNT(*) FROM citizens").fetchone()[0],
            "complaints": db.execute("SELECT COUNT(*) FROM complaints WHERE status != 'Resolved'").fetchone()[0],
            "certificates": db.execute("SELECT COUNT(*) FROM certificates WHERE status = 'Pending'").fetchone()[0],
            "tax": db.execute("SELECT COALESCE(SUM(amount),0) FROM taxes WHERE status='Paid'").fetchone()[0]
        }
        recent = db.execute("SELECT * FROM complaints ORDER BY id DESC LIMIT 5").fetchall()
    return render_template("dashboard.html", stats=stats, recent=recent)

@app.route("/citizens", methods=["GET", "POST"])
@login_required
def citizens():
    with get_db() as db:
        if request.method == "POST":
            db.execute("""INSERT INTO citizens(name,age,gender,phone,address,ward)
                          VALUES(?,?,?,?,?,?)""",
                       (request.form["name"], request.form.get("age") or None,
                        request.form.get("gender"), request.form.get("phone"),
                        request.form["address"], request.form.get("ward")))
            flash("Citizen added successfully.", "success")
            return redirect(url_for("citizens"))
        rows = db.execute("SELECT * FROM citizens ORDER BY id DESC").fetchall()
    return render_template("citizens.html", citizens=rows)

@app.route("/citizens/delete/<int:item_id>", methods=["POST"])
@login_required
def delete_citizen(item_id):
    with get_db() as db:
        db.execute("DELETE FROM citizens WHERE id=?", (item_id,))
    flash("Citizen record deleted.", "success")
    return redirect(url_for("citizens"))

@app.route("/complaints", methods=["GET", "POST"])
@login_required
def complaints():
    with get_db() as db:
        if request.method == "POST":
            db.execute("INSERT INTO complaints(citizen_name,subject,description) VALUES(?,?,?)",
                       (request.form["citizen_name"], request.form["subject"], request.form["description"]))
            flash("Complaint submitted.", "success")
            return redirect(url_for("complaints"))
        rows = db.execute("SELECT * FROM complaints ORDER BY id DESC").fetchall()
    return render_template("complaints.html", complaints=rows)

@app.route("/complaints/status/<int:item_id>", methods=["POST"])
@login_required
def complaint_status(item_id):
    status = request.form.get("status")
    if status in ["Pending", "In Progress", "Resolved"]:
        with get_db() as db:
            db.execute("UPDATE complaints SET status=? WHERE id=?", (status, item_id))
    return redirect(url_for("complaints"))

@app.route("/certificates", methods=["GET", "POST"])
@login_required
def certificates():
    with get_db() as db:
        if request.method == "POST":
            db.execute("INSERT INTO certificates(applicant,certificate_type,phone) VALUES(?,?,?)",
                       (request.form["applicant"], request.form["certificate_type"], request.form.get("phone")))
            flash("Certificate request added.", "success")
            return redirect(url_for("certificates"))
        rows = db.execute("SELECT * FROM certificates ORDER BY id DESC").fetchall()
    return render_template("certificates.html", certificates=rows)

@app.route("/certificates/status/<int:item_id>", methods=["POST"])
@login_required
def certificate_status(item_id):
    status = request.form.get("status")
    if status in ["Pending", "Approved", "Rejected"]:
        with get_db() as db:
            db.execute("UPDATE certificates SET status=? WHERE id=?", (status, item_id))
    return redirect(url_for("certificates"))

@app.route("/taxes", methods=["GET", "POST"])
@login_required
def taxes():
    with get_db() as db:
        if request.method == "POST":
            db.execute("INSERT INTO taxes(citizen_name,property_no,amount,status) VALUES(?,?,?,'Unpaid')",
                       (request.form["citizen_name"], request.form.get("property_no"), request.form["amount"]))
            flash("Tax record added.", "success")
            return redirect(url_for("taxes"))
        rows = db.execute("SELECT * FROM taxes ORDER BY id DESC").fetchall()
    return render_template("taxes.html", taxes=rows)

@app.route("/taxes/status/<int:item_id>", methods=["POST"])
@login_required
def tax_status(item_id):
    status = request.form.get("status")
    if status in ["Paid", "Unpaid"]:
        with get_db() as db:
            db.execute("UPDATE taxes SET status=? WHERE id=?", (status, item_id))
    return redirect(url_for("taxes"))

@app.route("/notices", methods=["GET", "POST"])
@login_required
def notices():
    with get_db() as db:
        if request.method == "POST":
            db.execute("INSERT INTO notices(title,message) VALUES(?,?)",
                       (request.form["title"], request.form["message"]))
            flash("Notice published.", "success")
            return redirect(url_for("notices"))
        rows = db.execute("SELECT * FROM notices ORDER BY id DESC").fetchall()
    return render_template("notices.html", notices=rows)

@app.route("/notices/delete/<int:item_id>", methods=["POST"])
@login_required
def delete_notice(item_id):
    with get_db() as db:
        db.execute("DELETE FROM notices WHERE id=?", (item_id,))
    return redirect(url_for("notices"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
