# Smart Gram Panchayat Management System

A Python Flask + SQLite mini-project for demonstrating digital Gram Panchayat administration.

## Features
- Admin login
- Dashboard with summary cards
- Citizen registration and deletion
- Complaint registration and status updates
- Birth/death/residence/other certificate request tracking
- House/property tax record management
- Village notice publishing and deletion
- SQLite database created automatically with sample records

## Run in VS Code

1. Extract the ZIP file.
2. Open the `Smart-Gram-Panchayat` folder in VS Code.
3. Open the VS Code terminal (`Terminal > New Terminal`).
4. Create and activate a virtual environment (recommended):

   **Windows PowerShell**
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, run:
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\venv\Scripts\Activate.ps1
   ```

5. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
6. Start the project:
   ```bash
   python app.py
   ```
7. Open this address in your browser: http://127.0.0.1:5000

## Demo login
- Username: `admin`
- Password: `admin123`

The database file `gram_panchayat.db` is created automatically the first time the app starts. Sample records are inserted only when the citizen table is empty.

## Important
This is an educational demonstration project, not an official government service. The demo login is hard-coded and is not suitable for real deployment. Change the secret key and implement proper authentication, authorization, validation, backups and HTTPS before any real use.
