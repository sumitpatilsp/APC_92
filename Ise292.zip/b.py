import numpy as np

marks = np.array([
    [[80, 85], [70, 75], [90, 95]],   
    [[75, 80], [65, 70], [85, 90]]    
])

print("3D Marks Array:")
print(marks)

subject_average = np.mean(marks, axis=(0, 2))

print("\nSubject wise Average:")
for i, avg in enumerate(subject_average):
    print("Subject", i + 1, "=", avg)
