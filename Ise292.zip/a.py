n = int(input("Enter number of students: "))

marks = []

for i in range(n):
    marks.append(float(input("Enter marks: ")))

maximum = max(marks)
minimum = min(marks)
average = sum(marks) / n

above_average = 0

for mark in marks:
    if mark > average:
        above_average += 1

print("Maximum marks =", maximum)
print("Minimum marks =", minimum)
print("Average marks =", average)
print("Students above average =", above_average)
